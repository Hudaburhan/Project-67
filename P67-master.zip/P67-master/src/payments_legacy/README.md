# Delete after July 13th 2020.

This is the _old_ legacy payment system we used
before getting on RevenueCat.

We keep it around to help us migrate folks onto
RevenueCat's payment system.

You shouldn't need to mess with it.
